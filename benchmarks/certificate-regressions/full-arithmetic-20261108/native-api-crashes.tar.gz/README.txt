Native producer crashes from the full arithmetic CORE census365550, nativea5123159. Two natural SMPT RwMutex inputs, RC-09 andRC-14, are preserved with original hashes, freshYices2.7.0 UNSAT outputs, native stage commands and complete logs. These cases were not minimized and were not rerun during packaging.

Each native export exits bySIGABRT(-6), with:
  cadical: fatal error: invalid API usage of void CaDiCaL::Solver::disconnect_external_propagator(): solver in invalid state
See exact diagnostics in export.err for original quoting/source location. This is a producer-side API-state abort, not classified as a memory-limit error or a successful export. Runs had3GiB address-space and256MiB per-file caps, but the root cause and whether either bound contributed remain untriaged. No export statistics were captured, so main-UNSAT/CORE completion and the internal failing phase are unknown. The checker was not invoked.

Reproduce ONE case inside an allocated SLURM worker with the pinned native binary:
  timeout --kill-after=5s 120s prlimit --as=3221225472 --fsize=268435456 -- /path/to/primo --quiet --stats --export-cnf /fresh/path/native.sexp --export-cnf-reduction=core RC-09/input.smt2 > export.out 2> export.err
ReplaceRC-09 withRC-14 for the second case. Do not treat the process abort or any partial output as a certificate. Replays/debugging with changed caps or builds must be reported separately. These crashes remain open producer defects and block performance/default-promotion claims until resolved or precisely explained.
