Four small natural producer examples from full CORE campaign365550, nativea5123159. No reduction/minimization of the original sources was attempted. They are representatives of four observed outcomes, not a complete failure set.

reconstruction-not-found:487-byte prime_cone_unsat_3 input; main UNSAT and CORE completed with one selected lemma; bounded reconstruction finishes without a cut proof.
reconstruction-resource-limit:prime_cone_unsat_7 input; main UNSAT and CORE completed; reconstruction reports ResourceLimit. The exact individual guard is not logged.
native-file-limit:process exits by SIGXFSZ(-25) under256MiB maximum file size; exact output/spool and execution phase are not logged.
native-allocation-limit:process exits2 with std::bad_alloc under3GiB address space; exact execution phase is not logged.

Reproduce one example in an allocated SLURM worker, with a qualified a5123159 binary:
  timeout --kill-after=5s 120s prlimit --as=3221225472 --fsize=268435456 -- /path/to/primo --quiet --stats --export-cnf /fresh/path/native.sexp --export-cnf-reduction=core CASE/input.smt2 > export.out 2> export.err
The source bytes and original logs are included with exact stage commands and counters in each case.json. No additional solver rerun was performed during packaging. Yices2.7.0 answered UNSAT on each original input in the primary campaign. Never treat export unknown/resource failure as a certificate.
