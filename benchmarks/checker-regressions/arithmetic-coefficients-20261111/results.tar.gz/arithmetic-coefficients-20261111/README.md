# Arithmetic coefficient adapter qualification, 11 November 2026

Final adapter and qualification implementation: 9b4b490f.
Native solver remains a5123159; native solving was not rerun. Checker revision
and executable hashes are recorded in kernel/summary.json and sparse/summary.json.

The generated-QF_LRA and generated-QF_LIA gates each contain 1000 cases: exact adapter replay, source
Z3 reference, and CaDiCaL exported-CNF UNSAT for valid certificates. SAT controls
must fail normally without publishing output. The kernel gate checks 18 inputs
in original/cheap/size/support profiles. The sparse probe has two authored
variants using weights (41,33,31,31), divisor 31 for LIA: size uses four rows,
support uses three. All raw proofs stream into the kernel; no proof streams,
external solver/checker code/binaries or binary challenge files are included.

Complete frozen workflow scripts and tests are in workflows/. Reproduce using
scripts/qualify_arithmetic_coefficients.py --mode generated --logic QF_LRA (and separately --logic QF_LIA), kernel or sparse
with --out OUT --workflow-git COMMIT --z3 Z3 --cadical CADICAL --micromath DIR
--micromath-git REV --build-report BUILD --lra-inputs INPUTS --examples EXAMPLES.
The kernel inputs directory retains all fourteen LRA files (strip lra- prefix
when preparing LRA_INPUTS); three authored/native LIA fixtures are in workflows.
A build report provides binaries.sha256 from the independently built checker.
Use the pinned checker revision and the report's fixed limits. Source/exported
CNF equivalence is outside this certificate boundary.

Text metadata paths use ${PRIMO_WORKDIR}, ${Z3}, ${CADICAL}, ${MICROMATH_DIR};
map generated-QF_LRA/, generated-QF_LIA/, kernel/ and sparse/ to the corresponding result directories.
Only private absolute path prefixes were redacted. No input or output
certificate, SMT query, model or proof diagnostic was otherwise changed.
MANIFEST.tsv verifies all payload files; it excludes its own row.
