# Medium arithmetic coefficient comparison, 11 November 2026

Three saved CORE-minimized successes: Rings, LassoRanker and Clock7 main
invariant. All profiles target the same original exported-CNF challenge:
original, cheap, size-first and support-first. Native solving/export is not
rerun. Optimized profiles first apply cheap passes and retain the checked
incumbent if an external call fails. Defaults: min-bits8, max32 queries,
max256 premises,1s/call and30s summed call time. This bounded search does not
establish a globally minimal witness.

Raw summaries/logs are in replay/shard-*/. Only verified profile results with
both process exits0 and exact challenge proven count as kernel successes.
Source/native/statement files are under inputs/ using selection primary paths.
Native LIA files have the v3 envelope; original v2 copies and each transformed
v2 compatibility file preserve all body bytes. No expanded raw proof, binary
challenge, executable or other solver/checker implementation is included.
Standalone optimizer SMT problems and stdout/stderr models remain available.

Use frozen scripts and wrapper under workflow/ with a qualified checker build,
matching binary hashes and the source paths in the comparison selection. The
nine-case discovery selection is also present for the shared unit tests; only
the three comparison inputs are included here. Private text metadata prefixes
are replaced by environment names. Input and output SMT/certificate bytes are
unchanged. Source-to-CNF equivalence remains trusted. Adapter and proof-pipeline
times are separate; their sum excludes shared challenge construction and the
small controller/envelope/hash overhead. Single-pass timings require repeated
confirmation before asserting a small speedup. MANIFEST.tsv excludes its own row.
