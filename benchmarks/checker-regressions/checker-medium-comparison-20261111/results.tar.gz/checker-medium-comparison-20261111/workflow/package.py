import hashlib,json,os,shutil,subprocess,tarfile
from pathlib import Path

root=Path(os.environ['PRIMO_WORKDIR'])
job=os.environ['CHECKER_COMPARE_JOB']
run=root/f'results/checker-medium-comparison-{job}'
workflow=Path(os.environ['CHECKER_MEDIUM_WORKFLOW'])
selection=json.loads((workflow/'benchmarks/checker-regressions/checker-medium-comparison-20261111/selection.json').read_text())
reports=[json.loads(p.read_text()) for p in sorted(run.glob('shard-*/summary.json'))]
assert len(reports)==3 and all(r['finished'] for r in reports)
rows=[row for r in reports for row in r['rows']]
assert sorted(r['index'] for r in rows)==list(range(len(selection['rows'])))
output=root/f'results/checker-compare-package-{os.environ["SLURM_JOB_ID"]}'
bundle=output/'checker-medium-comparison-20261111';bundle.mkdir(parents=True)
prefixes=[(os.environ['MICROMATH_UPDATE_DIR'],'${MICROMATH_DIR}'),(os.environ['PRIMO_SAT_SOLVER'],'${CADICAL}'),(str(root),'${PRIMO_WORKDIR}')]
prefixes.sort(key=lambda x:len(x[0]),reverse=True)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024**2),b''):h.update(block)
 return h.hexdigest()
def copy(p,d,raw=False):
 d.parent.mkdir(parents=True,exist_ok=True)
 if raw:shutil.copyfile(p,d)
 else:
  s=p.read_text()
  for old,new in prefixes:s=s.replace(old,new)
  d.write_text(s)
for path in run.rglob('*'):
 if path.is_file() and path.suffix in ('.json','.sexp','.smt2','.out','.err','.txt'):
  copy(path,bundle/'replay'/path.relative_to(run),raw=path.suffix in ('.sexp','.smt2'))
for case in selection['rows']:
 source=Path(os.environ['CHECKER_REPLAY_SAVED'])/case['primary_case']
 for filename,key in (('input.smt2','input'),('native.sexp','native'),('exported-cnf.smt2','statement')):
  p=source/filename
  assert digest(p)==case[key+'_sha256']
  copy(p,bundle/'inputs'/case['primary_case']/filename,raw=True)
 if case['logic']=='QF_LIA':
  copy(source/'micromath-v2.sexp',bundle/'inputs'/case['primary_case']/'micromath-v2.sexp',raw=True)
for p in workflow.rglob('*'):
 if p.is_file() and '__pycache__' not in p.parts:copy(p,bundle/'workflow'/p.relative_to(workflow),raw=p.suffix in ('.sexp','.smt2'))
copy(Path(__file__),bundle/'workflow/package.py')
for p in (root/'logs').glob(f'*{job}-*'):
 if p.is_file():copy(p,bundle/'logs'/p.name)
(bundle/'accounting.tsv').write_text(subprocess.check_output(['sacct','-j',job,'--format=JobID,State,ExitCode,Elapsed,MaxRSS','-P'],text=True))
(bundle/'README.md').write_text('# Medium arithmetic coefficient comparison, 11 November 2026\n\nThree saved CORE-minimized successes: Rings, LassoRanker and Clock7 main\ninvariant. All profiles target the same original exported-CNF challenge:\noriginal, cheap, size-first and support-first. Native solving/export is not\nrerun. Optimized profiles first apply cheap passes and retain the checked\nincumbent if an external call fails. Defaults: min-bits8, max32 queries,\nmax256 premises,1s/call and30s summed call time. This bounded search does not\nestablish a globally minimal witness.\n\nRaw summaries/logs are in replay/shard-*/. Only verified profile results with\nboth process exits0 and exact challenge proven count as kernel successes.\nSource/native/statement files are under inputs/ using selection primary paths.\nNative LIA files have the v3 envelope; original v2 copies and each transformed\nv2 compatibility file preserve all body bytes. No expanded raw proof, binary\nchallenge, executable or other solver/checker implementation is included.\nStandalone optimizer SMT problems and stdout/stderr models remain available.\n\nUse frozen scripts and wrapper under workflow/ with a qualified checker build,\nmatching binary hashes and the source paths in the comparison selection. The\nnine-case discovery selection is also present for the shared unit tests; only\nthe three comparison inputs are included here. Private text metadata prefixes\nare replaced by environment names. Input and output SMT/certificate bytes are\nunchanged. Source-to-CNF equivalence remains trusted. Adapter and proof-pipeline\ntimes are separate; their sum excludes shared challenge construction and the\nsmall controller/envelope/hash overhead. Single-pass timings require repeated\nconfirmation before asserting a small speedup. MANIFEST.tsv excludes its own row.\n')
files=sorted(p for p in bundle.rglob('*') if p.is_file())
(bundle/'MANIFEST.tsv').write_text(''.join(f'{digest(p)}\t{p.stat().st_size}\t{p.relative_to(bundle)}\n' for p in files))
archive=output/'results.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as t:t.add(bundle,arcname=bundle.name)
record={'sha256':digest(archive),'bytes':archive.stat().st_size,'payload_files':len(files),'regular_files':len(files)+1,'counts':dict(__import__('collections').Counter(r['status'] for r in rows))}
(output/'archive.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
