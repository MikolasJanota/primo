# Micromath resource case: smallest-input

Smallest input.primo certificate among all 799 observed OOM cases.

Source: `QG-classification/qg5/gensys_brn253.smt2`. The exported certificate has
1,315 CNF clauses and 1,157 retained
theory lemmas, after CORE reduction from 1,579 collected lemmas.

The saved Micromath `ac052d97ea441ca52cfd0a6b904fad8d34098a8e` run exited 1 in
`smt/prove-lrat` with `Proof export: out of memory`, under a 3 GiB address-space
limit. Only eight proof-output bytes had been written. See `metadata.json`.
These are unchanged original failure inputs, selected by size, not minimized
for this resource failure. Packaging was checksum-checked, without a new checker run.

On Linux with GNU `prlimit`, `timeout` and `sha256sum`, use a built Micromath checkout:

```sh
./replay.sh /absolute/path/to/Micromath
```

The script checks saved-file hashes, runs only the failed proof-generation
stage with the original 3 GiB/256 MiB per-file caps, and keeps logs and output
in a fresh `replay-output` directory. Expected historical exit status is 1;
newer Micromath versions may behave differently. The proof timeout defaults
to 30 seconds; `PROOF_TIMEOUT_SECONDS=120` can extend it on a slower machine.
The exact saved challenge and LRAT are included, so no Primo build, source SMT
formula, new SAT solve or CaDiCaL installation is needed. The partial eight-byte
proof output is omitted. No external source code or binaries are included.
