Complete 109-case checker replay, SLURM array 382354. All 8 workers completed.
Shard JSON is the primary profile/stage evidence; all native inputs were reused.
Private absolute paths and host fields are normalized. No raw proof streams or
binary challenges are stored. Saved optimization queries and diagnostics include
32 queries from a VPM adapter that later timed out without publishing output.
See the companion docs/coverage/remaining-checker-replay-20261110.json ledger
and docs/evidence/checker-replay-20261110.md for acceptance, limits and results.
