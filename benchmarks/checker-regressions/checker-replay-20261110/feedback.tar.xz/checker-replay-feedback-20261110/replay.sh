#!/usr/bin/env bash
set -euo pipefail
bundle=$(cd -- "$(dirname -- "$0")" && pwd)
if [[ ${1:-} == --list ]]; then
  python3 - "$bundle/cases.json" <<'LIST'
import json,sys
for name,row in json.load(open(sys.argv[1])).items(): print(name, row['logic'], row['file'], row['observed'], row['diagnostic'].strip())
LIST
  exit 0
fi
if (( $# != 2 )); then echo 'usage: replay.sh CASE FRESH_OUTPUT' >&2; exit 2; fi
: "${MICROMATH:?absolute built Micromath directory}"
: "${CADICAL:?absolute LRAT-capable CaDiCaL}"
case_name=$1
output=$2
read -r theory < <(python3 - "$bundle/cases.json" "$case_name" <<'LOGIC'
import json,sys
print({'QF_LRA':'lra','QF_LIA':'lia'}[json.load(open(sys.argv[1]))[sys.argv[2]]['logic']])
LOGIC
)
mkdir -- "$output"
output=$(cd -- "$output" && pwd)
mkdir "$output/pipe"
cd "$MICROMATH"
timeout --kill-after=2s 30s prlimit --as=3221225472 --fsize=268435456 -- \
  "$MICROMATH/build-axioms" --fragment finitary "$output/axioms.umd" \
  > "$output/axioms.out" 2> "$output/axioms.err"
timeout --kill-after=2s 60s prlimit --as=3221225472 --fsize=268435456 -- \
  "$MICROMATH/smt/build-$theory-challenge" "$output/axioms.umd" \
  "$bundle/$case_name/exported-cnf.smt2" "$output/challenge.umd" \
  > "$output/challenge.out" 2> "$output/challenge.err"
timeout --kill-after=2s 120s bash -c '
set -uo pipefail
save=()
if [[ -n $7 ]]; then save=(--save "$7"); fi
prlimit --as=3221225472 --fsize=268435456 -- \
  "$1" "$2" "$3" - --raw --cadical "$4" "${save[@]}" \
  2> "$6/producer.err" |
prlimit --as=3221225472 --fsize=268435456 -- \
  "$5" "$2" - > "$6/kernel.out" 2> "$6/kernel.err"
statuses=("${PIPESTATUS[@]}")
printf '"'"'%s %s\n'"'"' "${statuses[0]}" "${statuses[1]}" > "$6/exit-status.txt"
if (( statuses[0] != 0 || statuses[1] != 0 )); then exit 1; fi
grep -Fxq '"'"'challenge proven'"'"' "$6/kernel.out"
! grep -Fxq '"'"'Inconsistency proven!'"'"' "$6/kernel.out"
' feedback-pipe \
  "$MICROMATH/smt/prove-$theory" "$output/challenge.umd" \
  "$bundle/$case_name/certificate.sexp" "$CADICAL" \
  "$MICROMATH/check-solution" "$output/pipe" ""
