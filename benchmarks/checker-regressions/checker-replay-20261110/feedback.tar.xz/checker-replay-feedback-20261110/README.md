# Remaining Micromath checker failures, 10 November 2026

Five smallest natural representatives cover the remaining outcomes separately
for LRA/LIA pipeline timeouts and each of the three LIA allocation diagnostics.
Selection minimizes uncompressed statement plus certificate bytes within each
group of the complete 41-case current failure index. No delta reduction was run.
The original index had 109 failures; 68 now verify. This is exported-CNF checking,
not source-to-CNF verification. No checker implementation was inspected.

## Replay

Use a SLURM allocation or another appropriately resourced machine, not a login
host. Micromath revision: 62353d2da3035fdc544c374156bd616b44fb8640, qualified build
382225. Cases retain the exact inputs and diagnostics from replay array 382354.

```sh
bash replay.sh --list
export MICROMATH=/absolute/path/to/built/Micromath
export CADICAL=/absolute/path/to/LRAT-capable/cadical
bash replay.sh case-012 /fresh/output-clock10
```

Each output directory must be new. Limits: 30s axioms, 60s challenge, 120s overall
raw proof/kernel pipeline, 3 GiB address space and 256 MiB file bound per external
process. Timeout cleanup has a two-second kill grace. Expanded raw proofs are
not saved. A proof succeeds only with both exits zero, exact `challenge proven`,
and no `Inconsistency proven!`. Nonzero exit is an observed bounded failure;
inspect logs. Changing a build or limit creates a separate comparison profile.
The following kernel `invalid solution` after producer allocation failure does
not establish rejection of a complete proof. Allocation wording does not by
itself establish memory exhaustion or the internal cause of the limit.

For LRA, certificate.sexp is the original native version 2 export. For LIA it is
the saved version 2 compatibility copy: worker verification required its body
to equal the original version 3 export, with only byte 28 changing 3 to 2. The
native source hash, copy hash, statement hash and case identity remain in each
case.json. Every included statement/certificate was rehashed during packaging.
Private paths in receipts/logs are normalized; input bytes are unchanged.

The five natural inputs total about 0.98 GB before compression; large allocation
examples dominate this size. The complete ledger and raw profile/optimizer
metadata are separate companion artifacts. MANIFEST.json covers every other
payload with exact hashes and sizes. No claim of a minimized reproducer follows.
