import hashlib,json,os,shutil,subprocess,tarfile
from pathlib import Path

root=Path(os.environ['PRIMO_WORKDIR'])
job=os.environ['CHECKER_MEDIUM_JOB']
run=root/f'results/checker-medium-{job}'
workflow=Path(os.environ['CHECKER_MEDIUM_WORKFLOW'])
selection=json.loads((workflow/'benchmarks/checker-regressions/checker-medium-20261111/selection.json').read_text())
reports=[json.loads(p.read_text()) for p in sorted(run.glob('shard-*/summary.json'))]
assert len(reports)==4 and all(r['finished'] for r in reports)
rows=[row for r in reports for row in r['rows']]
assert sorted(r['index'] for r in rows)==list(range(len(selection['rows'])))
output=root/f'results/checker-medium-package-{os.environ["SLURM_JOB_ID"]}'
bundle=output/'checker-medium-20261111';bundle.mkdir(parents=True)
prefixes=[(os.environ['MICROMATH_UPDATE_DIR'],'${MICROMATH_DIR}'),(os.environ['PRIMO_SAT_SOLVER'],'${CADICAL}'),(str(root),'${PRIMO_WORKDIR}')]
prefixes.sort(key=lambda x:len(x[0]),reverse=True)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024**2),b''):h.update(block)
 return h.hexdigest()
def copy(p,d,raw=False):
 d.parent.mkdir(parents=True,exist_ok=True)
 if raw:shutil.copyfile(p,d)
 else:
  s=p.read_text()
  for old,new in prefixes:s=s.replace(old,new)
  d.write_text(s)
for path in run.rglob('*'):
 if path.is_file() and path.suffix in ('.json','.sexp','.smt2','.out','.err','.txt'):
  copy(path,bundle/'replay'/path.relative_to(run),raw=path.suffix in ('.sexp','.smt2'))
for case in selection['rows']:
 source=Path(os.environ['CHECKER_REPLAY_SAVED'])/case['primary_case']
 for filename,key in (('input.smt2','input'),('native.sexp','native'),('exported-cnf.smt2','statement')):
  p=source/filename
  assert digest(p)==case[key+'_sha256']
  copy(p,bundle/'inputs'/case['primary_case']/filename,raw=True)
 if case['logic']=='QF_LIA':
  copy(source/'micromath-v2.sexp',bundle/'inputs'/case['primary_case']/'micromath-v2.sexp',raw=True)
for p in workflow.rglob('*'):
 if p.is_file() and '__pycache__' not in p.parts:copy(p,bundle/'workflow'/p.relative_to(workflow),raw=p.suffix in ('.sexp','.smt2'))
copy(Path(__file__),bundle/'workflow/package.py')
for p in (root/'logs').glob(f'*{job}-*'):
 if p.is_file():copy(p,bundle/'logs'/p.name)
(bundle/'accounting.tsv').write_text(subprocess.check_output(['sacct','-j',job,'--format=JobID,State,ExitCode,Elapsed,MaxRSS','-P'],text=True))
(bundle/'README.md').write_text('''# Medium-cost successful arithmetic checker cases, 11 November 2026

Nine real problems from nine families, selected from saved successful CORE
certificates. Native solving/export was not rerun. Fresh replay results are
under replay/shard-*/summary.json. The selection gives original locations and
hashes plus historical timings/checker revisions; current timing is in replay.
Only status verified with both exits zero and challenge proven is success.
Cost bands: short below10s, medium10-90s, near_limit above90s. Times include
raw proof production and kernel checking, not challenge setup or coefficient
scanning. Proof-step categories do not measure CPU time inside the checker.

Inputs preserve the original source SMT-LIB, exported-CNF statement and native
certificate. LIA also preserves the version2 compatibility file with unchanged
body. Source-to-CNF equivalence remains trusted. No raw proof stream, binary
challenge, executable or external solver/checker implementation is included.
The cheap.sexp files were generated only to collect coefficient statistics;
this campaign kernel-checks the original certificates only. No optimizer is
called and this is not a paired optimization speed comparison.

Workflow source/tests/batch wrapper and selection are frozen under workflow/.
For exact replay set its saved-input root to this bundle's inputs/ and provide
the pinned checker checkout, build hashes and CaDiCaL. Text metadata paths use
${PRIMO_WORKDIR}, ${MICROMATH_DIR} and ${CADICAL}; source/certificate bytes are
unchanged. To replay manually, build a challenge from exported-cnf.smt2, then
pipe smt/prove-lra or prove-lia with --raw to check-solution; use the preserved
micromath-v2.sexp for LIA. The generic PIPE command is in the frozen helper.
MANIFEST.tsv verifies every payload file, excluding its own row.
''')
files=sorted(p for p in bundle.rglob('*') if p.is_file())
(bundle/'MANIFEST.tsv').write_text(''.join(f'{digest(p)}\t{p.stat().st_size}\t{p.relative_to(bundle)}\n' for p in files))
archive=output/'results.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as t:t.add(bundle,arcname=bundle.name)
record={'sha256':digest(archive),'bytes':archive.stat().st_size,'payload_files':len(files),'regular_files':len(files)+1,'counts':dict(__import__('collections').Counter(r['status'] for r in rows))}
(output/'archive.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
