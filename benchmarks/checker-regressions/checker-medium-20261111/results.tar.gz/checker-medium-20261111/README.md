# Medium-cost successful arithmetic checker cases, 11 November 2026

Nine real problems from nine families, selected from saved successful CORE
certificates. Native solving/export was not rerun. Fresh replay results are
under replay/shard-*/summary.json. The selection gives original locations and
hashes plus historical timings/checker revisions; current timing is in replay.
Only status verified with both exits zero and challenge proven is success.
Cost bands: short below10s, medium10-90s, near_limit above90s. Times include
raw proof production and kernel checking, not challenge setup or coefficient
scanning. Proof-step categories do not measure CPU time inside the checker.

Inputs preserve the original source SMT-LIB, exported-CNF statement and native
certificate. LIA also preserves the version2 compatibility file with unchanged
body. Source-to-CNF equivalence remains trusted. No raw proof stream, binary
challenge, executable or external solver/checker implementation is included.
The cheap.sexp files were generated only to collect coefficient statistics;
this campaign kernel-checks the original certificates only. No optimizer is
called and this is not a paired optimization speed comparison.

Workflow source/tests/batch wrapper and selection are frozen under workflow/.
For exact replay set its saved-input root to this bundle's inputs/ and provide
the pinned checker checkout, build hashes and CaDiCaL. Text metadata paths use
${PRIMO_WORKDIR}, ${MICROMATH_DIR} and ${CADICAL}; source/certificate bytes are
unchanged. To replay manually, build a challenge from exported-cnf.smt2, then
pipe smt/prove-lra or prove-lia with --raw to check-solution; use the preserved
micromath-v2.sexp for LIA. The generic PIPE command is in the frozen helper.
MANIFEST.tsv verifies every payload file, excluding its own row.
