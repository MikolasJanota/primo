Paired checker replay of four preserved representatives, 10 November 2026.
Build job 382225; replay array 382226. Old cfd36f46 versus new 62353d2.

Both builds use the same compiler and dependency hashes. Both replay profiles
use the same saved handoff inputs and 30/60/120-second stage limits, with
3 GiB address space and 256 MiB per-file bounds. The source handoff and proof
inputs were not regenerated. No native solver or source-to-CNF adapter ran.

A successful proof row requires both pipeline exits zero and exact
challenge proven output without an inconsistency marker. challenge-p15 only
builds a challenge; it is not an UNSAT proof. No raw proof file is stored.

Summaries and logs normalize installation paths; private host names are
omitted. source_raw_sha256 identifies each original ignored raw summary.
The public ledger records job IDs, pins, commands with path placeholders,
input hashes, stage timings and historical failure diagnostics. Accounting
omits node names; build/compiler and dependency provenance is in builds.json.

These are four preselected failures, not an evaluation of all 109 indexed
cases or a general speed claim. The checker implementation was not inspected
or modified. Original artifacts remain under the campaign result directory
named by the ledger. No full native/checker qualification is claimed.
