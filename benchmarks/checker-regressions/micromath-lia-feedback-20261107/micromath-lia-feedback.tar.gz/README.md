# Micromath LIA exported-CNF feedback

Pinned checker: 8f9cff132140462b141183ddb9cb88a9beb80a4f. Original pilot: SLURM 362736.
Independent audit: SLURM 362757. Yices version:

Yices 2.7.0
Copyright SRI International.
Linked with GMP 6.3.0
Copyright Free Software Foundation, Inc.
Build date: 2025-07-17
Platform: x86_64-pc-linux-gnu (release/static)
Revision: 4f19700f0e272f4a68250080d12a873523bc7ac3


Each included case passed Yices UNSAT checks on both the original SMT-LIB and
exported-CNF statement; exact Python integer-cut replay and independent CaDiCaL
propositional UNSAT; regenerated statement byte equality; native/copy hashes;
and the explicit one-byte LIA version-3 to version-2 envelope-copy check.
No producer-side defect was found by these checks. This does not prove the
original-to-CNF transformation or establish checker soundness.

Cases marked checker_error_reproduced were replayed during the audit.
Included resource-limit cases retain the original pilot's logs and budgets;
their checker runs were not repeated by this audit. Limits are feedback about
this workload and budget, not claims of a checker correctness bug. The checker
implementation was neither inspected nor modified; no upstream fetch occurred.
Read manifest.json and each case.json for the actual included subset/status.

From an allocated Linux compute node, after building the pinned checker targets:

    bash replay.sh /path/to/Micromath /path/to/cadical CASE_DIRECTORY /fresh/log/directory

The script builds the challenge from exported-cnf.smt2, reads micromath-v2.sexp,
and pipes --raw proof output directly to check-solution. It uses 3 GiB address
space and 256 MiB maximum file size per child, 30 seconds for challenge building,
and 60 seconds per proof/kernel process. Error exits are expected for these
feedback cases. Original pipeline runs used one overall 60-second proof deadline;
the standalone script uses per-process deadlines and prints both exit codes.
An error exit or timeout is not a verified proof. Valid acceptance requires both
processes to exit zero and the kernel to print exactly challenge proven.

Optional independent checks (Yices and CaDiCaL are external executables):

    /path/to/yices-smt2 CASE_DIRECTORY/input.smt2
    /path/to/yices-smt2 CASE_DIRECTORY/exported-cnf.smt2
    python3 check_lia_certificate.py CASE_DIRECTORY/native.sexp --sat-solver /path/to/cadical

Native certificates are unchanged producer bytes; micromath-v2.sexp changes only
byte 28 from 3 to 2. Original sources are for provenance/reference checks. The
statement being kernel-checked is the exported CNF. No challenge dumps, checker
binaries or raw proofs are bundled. These are original instances, not minimized.
