Farkas adapter qualification, 10 November 2026.
Inputs and three profiles: real/inputs and real/<case>/{original,cheap,optimized}.
No proof text, axioms or binary challenge is retained: rebuild these with the
pinned Micromath. Each pipe/ directory contains strict acceptance diagnostics.
Generated 1000-case metadata is in generated/summary.json; reproduce exact
inputs with qualify_farkas_coefficients.py --mode generated, seed 20261110.
Absolute private paths in metadata/logs are replaced with environment names.
Certificate payloads are unchanged. See docs/coverage/farkas-coefficients-20261110.json
and docs/leads/farkas-coefficient-minimization.md for provenance and limitations.
