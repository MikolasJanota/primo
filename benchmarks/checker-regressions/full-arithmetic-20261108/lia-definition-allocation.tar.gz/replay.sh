#!/usr/bin/env bash
set -euo pipefail
: "${MICROMATH:?path to built Micromath cfd36f46}"
: "${CADICAL:?path to LRAT-capable CaDiCaL}"
base=$(cd -- "$(dirname -- "$0")" && pwd)
case "${1:?choose wisa-definition-allocation}" in
  wisa-definition-allocation) theory=lia; cert=micromath-v2.sexp;;
  *) echo 'unknown case' >&2; exit 2;;
esac
item="$base/$1"
mkdir -- "${2:?fresh output directory}"
out=$(cd -- "$2" && pwd)
timeout --kill-after=5s 30s prlimit --as=3221225472 --fsize=268435456 --   "$MICROMATH/build-axioms" --fragment finitary "$out/axioms.umd"
timeout --kill-after=5s 60s prlimit --as=3221225472 --fsize=268435456 --   "$MICROMATH/smt/build-$theory-challenge" "$out/axioms.umd" "$item/exported-cnf.smt2" "$out/challenge.umd"
timeout --kill-after=5s 120s bash -c '
  set -o pipefail
  prlimit --as=3221225472 --fsize=268435456 --     "$1/smt/prove-$2" "$3/challenge.umd" "$4/$5" - --raw --cadical "$6"       2> "$3/producer.err" |
  prlimit --as=3221225472 --fsize=268435456 --     "$1/check-solution" "$3/challenge.umd" - > "$3/kernel.out" 2> "$3/kernel.err"
  codes=("${PIPESTATUS[@]}")
  printf "%s %s\n" "${codes[0]}" "${codes[1]}" > "$3/exit-status.txt"
  (( codes[0] == 0 && codes[1] == 0 ))
' replay-pipe "$MICROMATH" "$theory" "$out" "$item" "$cert" "$CADICAL"
grep -Fxq 'challenge proven' "$out/kernel.out"
! grep -Fxq 'Inconsistency proven!' "$out/kernel.out"
