Small natural Micromath producer-failure replay from the full arithmetic CORE campaign365550, checked with nativea5123159, Micromathcfd36f46 and Yices2.7.0. This is an additional example, distinct from the large NEC parsing-OOM and LRA pipeline-timeout packet.

Original input:wisa/wisa5.smt2. Yices answeredUNSAT. Native main solving, CORE reduction and all10598retained lemma reconstructions completed. Native certificate18892343B; exported-CNF statement270318B. The live --raw producer/kernel pipeline then exits[1,1]. Its complete producer diagnostic is:
  Logic failure: definition index allocation
The kernel subsequently prints invalid solution. This follows producer failure and is not evidence of rejection of a complete proof. The exact cause of the producer diagnostic remains untriaged; the word allocation alone does not establish an out-of-memory cause or which limit fired. The primary run used3GiB address space and256MiB per-file bounds. The checker implementation was not inspected or modified.

This replay verifies exported-cnf.smt2, not the original SMT-LIB-to-CNF transformation. Original input and source/native/statement hashes are included for context. micromath-v2.sexp is a version-2 compatibility copy of the native version-3 certificate:only header byte28 changes from3to2; the body is verbatim. Restoring that byte reproduces the recorded native hash and length.

Run ONE case in an allocated worker (or another appropriately resourced machine):
  MICROMATH=/path/to/Micromath CADICAL=/path/to/cadical bash replay.sh wisa-definition-allocation /fresh/output
The script builds finitary axioms, constructs the challenge from exported-cnf.smt2, and pipes the raw proof to the independent kernel without saving a raw proof. It retains the primary60s challenge and120s overall proof/kernel budgets, with3GiB/256MiB per-process bounds. It returns nonzero on failure or deadline; inspect producer.err/kernel.err/kernel.out and exit-status.txt if written. replay.sh was syntax checked only; packaging performed no additional solver/checker run. Changed limits/builds must be reported separately.
