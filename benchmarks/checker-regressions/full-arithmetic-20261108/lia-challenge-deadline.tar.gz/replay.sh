#!/usr/bin/env bash
set -euo pipefail
: "${MICROMATH:?path to built Micromath cfd36f46}"
base=$(cd -- "$(dirname -- "$0")" && pwd)
mkdir -- "${1:?fresh output directory}"
out=$(cd -- "$1" && pwd)
timeout --kill-after=5s 30s prlimit --as=3221225472 --fsize=268435456 --   "$MICROMATH/build-axioms" --fragment finitary "$out/axioms.umd"
timeout --kill-after=5s 60s prlimit --as=3221225472 --fsize=268435456 --   "$MICROMATH/smt/build-lia-challenge" "$out/axioms.umd" "$base/exported-cnf.smt2" "$out/challenge.umd"   > "$out/challenge.out" 2> "$out/challenge.err"
printf '%s\n' 'Challenge built; proof not attempted.'
