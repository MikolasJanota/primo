import hashlib,json,os,shutil,subprocess,tarfile
from pathlib import Path

root=Path(os.environ['PRIMO_WORKDIR'])
job=os.environ['CHECKER_PROFILE_JOB']
run=root/f'results/checker-gprof-{job}'
workflow=Path(os.environ['CHECKER_PROFILE_WORKFLOW'])
selection=json.loads((workflow/'benchmarks/checker-regressions/checker-medium-comparison-20261111/selection.json').read_text())
reports=[json.loads(p.read_text()) for p in sorted(run.glob('case-*/summary.json'))]
assert len(reports)==3
retry=Path(os.environ['CHECKER_PROFILE_RETRY'])
recovered=json.loads((retry/'summary.json').read_text())
assert recovered['finished'] and recovered['status']=='profiled'
assert recovered['case']==reports[2]['case']
assert all(p['status']=='verified' for r in reports for p in r['profiles'].values())
assert recovered['profiles']['gprof']['kernel_steps']==reports[2]['profiles']['baseline']['kernel_steps']
final_reports=reports[:2]+[recovered]
assert all(r['finished'] and r['status']=='profiled' for r in final_reports)
assert sorted(r['index'] for r in reports)==list(range(3))
output=root/f'results/checker-gprof-package-{os.environ["SLURM_JOB_ID"]}'
bundle=output/'checker-gprof-20261111';bundle.mkdir(parents=True)
prefixes=[(os.environ['MICROMATH_PROFILE_DIR'],'${MICROMATH_PROFILE_DIR}'),(os.environ['MICROMATH_UPDATE_DIR'],'${MICROMATH_DIR}'),(os.environ['PRIMO_SAT_SOLVER'],'${CADICAL}'),(str(root),'${PRIMO_WORKDIR}'),('${REMOTE_HOME}','${REMOTE_HOME}')]
prefixes.sort(key=lambda x:len(x[0]),reverse=True)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024**2),b''):h.update(block)
 return h.hexdigest()
def copy(p,d,raw=False):
 d.parent.mkdir(parents=True,exist_ok=True)
 if raw:shutil.copyfile(p,d)
 else:
  s=p.read_text()
  for old,new in prefixes:s=s.replace(old,new)
  d.write_text(s)
for path in run.rglob('*'):
 if path.is_file() and (path.suffix in ('.json','.out','.err','.txt','.time') or '.gmon.' in path.name):
  copy(path,bundle/'replay'/path.relative_to(run),raw='.gmon.' in path.name)
for path in retry.rglob('*'):
 if path.is_file() and (path.suffix in ('.json','.out','.err','.txt','.time') or '.gmon.' in path.name):
  copy(path,bundle/'retry'/path.relative_to(retry),raw='.gmon.' in path.name)
for case in selection['rows']:
 source=Path(os.environ['CHECKER_REPLAY_SAVED'])/case['primary_case']
 for filename,key in (('input.smt2','input'),('native.sexp','native'),('exported-cnf.smt2','statement')):
  p=source/filename
  assert digest(p)==case[key+'_sha256']
  copy(p,bundle/'inputs'/case['primary_case']/filename,raw=True)
 if case['logic']=='QF_LIA':copy(source/'micromath-v2.sexp',bundle/'inputs'/case['primary_case']/'micromath-v2.sexp',raw=True)
for p in workflow.rglob('*'):
 if p.is_file() and '__pycache__' not in p.parts:copy(p,bundle/'workflow'/p.relative_to(workflow))
copy(Path(__file__),bundle/'workflow/package.py')
copy(Path(__file__).with_name('package.sbatch'),bundle/'workflow/package.sbatch')
copy(Path(__file__).with_name('retry.sbatch'),bundle/'workflow/retry.sbatch')
for label,report in (('qualified',Path(os.environ['CHECKER_UPDATE_BUILD_REPORT'])),('gprof',Path(os.environ['CHECKER_PROFILE_BUILD_REPORT']))):
 for p in report.iterdir():
  if p.is_file():copy(p,bundle/'build'/label/p.name)
for previous in ('382591','382595',job,os.environ['CHECKER_PROFILE_RETRY_JOB']):
 for p in (root/'logs').glob(f'*{previous}-*'):
  if p.is_file():copy(p,bundle/'logs'/p.name)
(bundle/'accounting.tsv').write_text(subprocess.check_output(['sacct','-j',f'382587,382591,382595,{job},382602,{os.environ["CHECKER_PROFILE_RETRY_JOB"]}','--format=JobID,State,ExitCode,Elapsed,MaxRSS,NodeList','-P'],text=True))
(bundle/'README.md').write_text('''# Gprof checker profiles, 11 November 2026

Three original saved CORE certificates: Rings, LassoRanker, Clock7 main invariant.
Both the qualified and isolated -O2 -g -Wall -Wextra -pg builds prove the same
original exported-CNF challenges, with identical proof-step categories/counts.
No native solve/export or coefficient optimization is repeated here. Raw proof
streams are pipes, without disk persistence. GNU time measures each process
and its waited-for children; external SAT execution is not instrumented by gprof.
Gprof reports are normal function tables/call graphs, without source annotation.

replay/case-*/ has the per-process GNU time reports, gmon files, gprof tables,
producer/kernel diagnostics and atomic summaries. Instrumented elapsed times
include profiling overhead and are not optimization benchmark results. Shared
libraries and uninstrumented dependencies have incomplete sampling/call coverage;
call-graph child times are estimates. Input bytes and gmon records are unchanged.
Private text metadata prefixes are normalized. No executable binaries, binary
challenges, raw expanded proofs, or checker implementation are included.

Build flags, compiler, CPU metadata and executable hashes are under build/.
To replay, build the pinned checker revision using workflow/scripts/slurm_build_
micromath_gprof.sbatch in a detached worktree, preserving the qualified binaries.
Use workflow/scripts/slurm_profile_checker_medium.sbatch and its required
environment on the saved inputs/ tree. Stage all Python dependencies from the
frozen workflow. The qualified GNU time executable must exist on shared storage;
its hash is pinned by the wrapper and recorded in every summary. gmon records
require the exact corresponding executable (hashes recorded) for reliable
symbol resolution; the rendered gprof tables are directly readable without it.

Accounting also records two setup-only failed arrays: 382591 missing Python
import and 382595 missing compute-node /usr/bin/time. They are not checker
failures. All six initial pipeline proofs pass. Clock7's gprof producer exceeds the default
call-graph buffer, though its proof passes; original raw records are retained.
Clock7 is replayed alone with GLIBC_TUNABLES=glibc.gmon.minarcs=1000000:
glibc.gmon.maxarcs=1000000 (one colon-separated environment value), in retry/.
Both retry proofs also pass, with complete profiles. Use the initial baseline
timings for all cases and retry gprof data only for Clock7. Archive dependency
382602 was cancelled after the profiling-only failure; the replacement job
collects both original and recovered records.
MANIFEST.tsv hashes every payload except itself.
''')
files=sorted(p for p in bundle.rglob('*') if p.is_file())
(bundle/'MANIFEST.tsv').write_text(''.join(f'{digest(p)}\t{p.stat().st_size}\t{p.relative_to(bundle)}\n' for p in files))
archive=output/'results.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as t:t.add(bundle,arcname=bundle.name)
record={'sha256':digest(archive),'bytes':archive.stat().st_size,'payload_files':len(files),'regular_files':len(files)+1}
(output/'archive.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
