# Gprof checker profiles, 11 November 2026

Three original saved CORE certificates: Rings, LassoRanker, Clock7 main invariant.
Both the qualified and isolated -O2 -g -Wall -Wextra -pg builds prove the same
original exported-CNF challenges, with identical proof-step categories/counts.
No native solve/export or coefficient optimization is repeated here. Raw proof
streams are pipes, without disk persistence. GNU time measures each process
and its waited-for children; external SAT execution is not instrumented by gprof.
Gprof reports are normal function tables/call graphs, without source annotation.

replay/case-*/ has the per-process GNU time reports, gmon files, gprof tables,
producer/kernel diagnostics and atomic summaries. Instrumented elapsed times
include profiling overhead and are not optimization benchmark results. Shared
libraries and uninstrumented dependencies have incomplete sampling/call coverage;
call-graph child times are estimates. Input bytes and gmon records are unchanged.
Private text metadata prefixes are normalized. No executable binaries, binary
challenges, raw expanded proofs, or checker implementation are included.

Build flags, compiler, CPU metadata and executable hashes are under build/.
To replay, build the pinned checker revision using workflow/scripts/slurm_build_
micromath_gprof.sbatch in a detached worktree, preserving the qualified binaries.
Use workflow/scripts/slurm_profile_checker_medium.sbatch and its required
environment on the saved inputs/ tree. Stage all Python dependencies from the
frozen workflow. The qualified GNU time executable must exist on shared storage;
its hash is pinned by the wrapper and recorded in every summary. gmon records
require the exact corresponding executable (hashes recorded) for reliable
symbol resolution; the rendered gprof tables are directly readable without it.

Accounting also records two setup-only failed arrays: 382591 missing Python
import and 382595 missing compute-node /usr/bin/time. They are not checker
failures. All six initial pipeline proofs pass. Clock7's gprof producer exceeds the default
call-graph buffer, though its proof passes; original raw records are retained.
Clock7 is replayed alone with GLIBC_TUNABLES=glibc.gmon.minarcs=1000000:
glibc.gmon.maxarcs=1000000 (one colon-separated environment value), in retry/.
Both retry proofs also pass, with complete profiles. Use the initial baseline
timings for all cases and retry gprof data only for Clock7. Archive dependency
382602 was cancelled after the profiling-only failure; the replacement job
collects both original and recovered records.
MANIFEST.tsv hashes every payload except itself.
